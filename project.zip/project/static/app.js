document.getElementById("letme").addEventListener('click', function (){
    document.getElementById("checkpass").innerText = 'Wrong pass';
})