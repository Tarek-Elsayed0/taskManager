from flask import Flask, render_template, request, redirect

app = Flask(__name__)

import sqlite3
con = sqlite3.connect('example.db', check_same_thread=False)
cur = con.cursor()

# Create table
# cur.execute('CREATE TABLE mytable (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, data TEXT NOT NULL)')

# cur.execute("INSERT INTO mytable (name, data) VALUES('task1', 'today')")
# cur.execute("INSERT INTO mytable (name, data) VALUES('task2', 'today')")
# cur.execute("INSERT INTO mytable (name, data) VALUES('task3', 'today')")
# cur.execute("INSERT INTO mytable (name, data) VALUES('task4', 'today')")
# cur.execute("INSERT INTO mytable (name, data) VALUES('task5', 'today')")
# con.commit()

# SELECT to_json(result) FROM (SELECT * FROM TABLE table) result)
# mytasks = cur.execute("SELECT * FROM mytable")


@app.route("/")
def index():
    return render_template("index.html")

@app.route("/enter", methods=["POST"])
def home():
    if request.form.get("passwd") == "0000":
        mytasks = cur.execute("SELECT * FROM mytable to_json")
        return render_template("myPage.html", tasks=mytasks)
    else:
        return render_template("index.html", mssg="wrong pass")

@app.route("/done", methods=["POST"])
def done():
    num = request.form.get("tasknum")
    cur.execute("DELETE FROM mytable WHERE id = ?", (num,))
    con.commit()
    mytasks = cur.execute("SELECT * FROM mytable to_json")
    return render_template("myPage.html", tasks=mytasks)


@app.route("/add", methods=["POST"])
def add():
    taskname = request.form.get("taskname")
    tasktime = request.form.get("tasktime")
    cur.execute("INSERT INTO mytable (name, data) VALUES(?, ?)", (taskname,tasktime))
    mytasks = cur.execute("SELECT * FROM mytable to_json")
    return render_template("myPage.html", tasks=mytasks)
